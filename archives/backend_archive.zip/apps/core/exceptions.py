class ObjectAlreadyExistsException(BaseException):
    """Объект уже существует."""

    pass
