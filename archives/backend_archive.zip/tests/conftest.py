pytest_plugins = [
    "tests.fixtures.fixtures_employers",
    "tests.fixtures.fixtures_vacancies",
    "tests.fixtures.fixtures_attributes",
]
