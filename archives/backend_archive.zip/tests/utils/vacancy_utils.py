GOOD_VACANCY_DATA = {
    "title": "Разработчик на PHP",
    "is_published": True,
    "description": "Много слов и много требований прямо тут",
    "min_salary": 100000,
    "max_salary": 300000,
}
